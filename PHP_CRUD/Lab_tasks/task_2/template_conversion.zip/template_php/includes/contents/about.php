<!-- ++++++++++++++++++++ ABOUT CONTENT Part ++++++++++++++++++++++++-->
    <div class="right_section">
      <div class="common_content">
        <h2>About</h2>
        <hr>
        <p>LOL</p>
        </div>
      <div class="top_content">
        <div class="column_one">
          <h2>Subscription</h2>
          <p>DEMO About</p>
         <br>
         <p><a href="#" class="btn">Read more</a></p>
        </div>
        <div class="column_two border_left">
          <h2>Other Services</h2>
          <p>AWESOME Mii</p>
         <br>
         <p><a href="#" class="btn">Read more</a></p></div>
      </div>
    </div>
    
    <div class="clear"></div>
