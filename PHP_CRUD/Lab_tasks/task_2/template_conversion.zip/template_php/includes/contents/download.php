<!-- ++++++++++++++++++++ MAIN CONTENT Part ++++++++++++++++++++++++-->
    <div class="right_section">
      <div class="common_content">
        


        </div>
      <div class="top_content">
        <div class="column_one">
          
         <br>
         <p><a href="#" class="btn">Read more</a></p>
        </div>
        <div class="column_two border_left">
          
          </div>
      </div>
    </div>
    
    <div class="clear"></div>
