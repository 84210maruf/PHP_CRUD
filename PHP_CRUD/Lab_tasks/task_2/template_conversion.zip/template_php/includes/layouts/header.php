<!-- HEAD Data Part -->
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>HTML TEMPLATE to PHP</title>
<meta name="description" content="A description of your website">
<meta name="keywords" content="keyword1, keyword2, keyword3">
<link href="css/style.css" rel="stylesheet" type="text/css">
</head>
<!-- TOP BANNER Part -->
<body>
<div id="wrapper"> 
  <div id="header"> 
    <div class="top_banner">
      <h1>My First Site</h1>
      <p>Enter Site Slogan</p>
    </div>

  </div>
