<!-- NAVIGATION Part -->
  
  <div id="page_content">
    
    <div class="navigation">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="?page=about">About</a></li>
        <li><a href="?page=download">Download</a></li>
        <li><a href="#">New Page 3</a></li>
        <li><a href="#">New Page 4</a></li>
        <li><a href="#">New Page 5</a></li>
      </ul>
    </div>