<!-- FOOTER CONTENT Part -->

    <!--start footer from here-->
    <div id="footer">Copyright &copy; 2014. Design by <a href="http://www.htmltemplates.net" target="_blank">html templates</a><br>
    
    <!--DO NOT remove footer link-->
    <!--Template designed by--><a href="http://www.htmltemplates.net"><img src="images/footer.gif" class="copyright" alt="htmltemplates.net"></a></div>
	
    <!--/. end footer from here-->
  </div>
  
</div>

</body>
</html>